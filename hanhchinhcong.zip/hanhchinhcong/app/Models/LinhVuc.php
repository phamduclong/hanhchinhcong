<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LinhVuc extends Model
{
    //
    protected $table = 'linhvuc';
}
