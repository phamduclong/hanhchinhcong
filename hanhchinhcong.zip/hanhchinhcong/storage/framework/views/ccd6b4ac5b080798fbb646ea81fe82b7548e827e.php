<?php $__env->startSection('content'); ?>
nộp hồ sơ
<?php $__env->stopSection(); ?>
<?php echo $__env->make('citizen.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/citizen/nophoso.blade.php ENDPATH**/ ?>