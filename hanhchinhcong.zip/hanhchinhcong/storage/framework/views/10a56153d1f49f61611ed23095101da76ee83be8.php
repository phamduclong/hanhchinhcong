<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AdminLTE 2 | Blank Page</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="<?php echo e(asset('asset1/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset1/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset1/css/AdminLTE.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset1/css/_all-skins.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset1/css/jquery-ui.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset1/css/style.css')); ?>" />
    <script src="<?php echo e(asset('asset1/js/angular.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset1/js/app.js')); ?>"></script>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

    <?php echo $__env->make('admin.layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- =============================================== -->

    <!-- Content Wrapper. Contains page content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- /.content-wrapper -->

    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->

<script src="<?php echo e(asset('asset1/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset1/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('asset1/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset1/js/adminlte.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset1/js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('asset1/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset1/tinymce/config.js')); ?>"></script>
<script src="<?php echo e(asset('asset1/js/function.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hanhchinhcong\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>