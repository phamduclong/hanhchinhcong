<?php $__env->startSection('content'); ?>

<script>

    
    var pusher = new Pusher('aa4d6d77e1498fc55765', {
      cluster: 'ap1'
    });

    var channel = pusher.subscribe('my-channel-manager');
    channel.bind('my-event-manager', function(data) {
      //alert(JSON.stringify(data));
      //console.log(data.hs[0].id);
      //console.log(data.hs[0].status);
      

      console.log(data.contentOfMessage);
      // console.log(sessionStorage.getItem('numberOfMessage'));
      
      var id = String(data.hs[0].id);
      var trangthai = 'trangthai'+id;
      var length = data.contentOfMessage.length;


      document.getElementById(trangthai).innerHTML = data.hs[0].status;
      document.getElementById('thongbao'+id).innerHTML = data.hs[0].note;

      document.getElementById('messageThongbao').innerHTML = data.numberOfMessage;

      // if(data.numberOfMessage != 0){

      //   document.getElementById('HIDE_TEXT').innerHTML = "";
      //   document.getElementById('THEM_MESSAGE').innerHTML = data.contentOfMessage[length-1];
      // }else{
      //   document.getElementById('THEM_MESSAGE').innerHTML = "";
      // }

      //document.getElementById('THEM_MESSAGE').innerHTML = data.contentOfMessage[length-1] ;
      // document.getElementById('CONTENT_MESSAGE').appendChild('<p>hhhhhhh</p>')

      // if(document.getElementById('CONTENT_MESSAGE').lastChild.innerHTML != data.contentOfMessage[length-1]){

        // if(length > 0){

        // document.getElementById('HIDE_TEXT').innerHTML = "";


        
        // var node = document.createElement("p");
        // var textnode = document.createTextNode(data.contentOfMessage[length-1]);
        // node.appendChild(textnode);  
        // node.setAttribute("style", "color: red;font-weight:bold");
        // node.setAttribute("class","dropdown-item");
        // document.getElementById("CONTENT_MESSAGE").appendChild(node);

        // var node2 = document.createElement("div");
        // node2.setAttribute("class","dropdown-divider");
        // document.getElementById("CONTENT_MESSAGE").appendChild(node2);
        // }
      // }

      // if(document.getElementById('CONTENT_MESSAGE')){
        document.getElementById('CONTENT_MESSAGE').innerHTML = "";
        // if(length == 0){
        //   document.getElementById('HIDE_TEXT').innerHTML = 'Không Có Thông báo mới';
        // }
      // }
        // var root = document.createElement('div');
        // root.setAttribute('id','CONTENT_MESSAGE');
      


      for(var i = 0 ; i < length; ++i){

        var node = document.createElement("p");
        var textnode = document.createTextNode(data.contentOfMessage[i]);
        node.appendChild(textnode);  
        node.setAttribute("style", "color: red;font-weight:bold");
        node.setAttribute("class","dropdown-item");
        document.getElementById("CONTENT_MESSAGE").appendChild(node);

        var node2 = document.createElement("div");
        node2.setAttribute("class","dropdown-divider");
        document.getElementById("CONTENT_MESSAGE").appendChild(node2);

      }


    

      

  


    });

    //Xử lý Thông báo

    
      
</script>


<h2>Danh sách hồ sơ của bạn</h2>


<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">STT</th>
      <th scope="col">Họ Tên Người Nộp</th>
      <th scope="col">File Hồ Sơ</th>
      <th scope="col">Trạng Thái Xử Lý</th>
      <th scope="col">Tên Cán Bộ Xử Lý</th>
      <th scope="col">Thông Báo Từ Cán bộ</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $hoso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hoso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <th scope="row"><?php echo e($hoso->id); ?></th>
        <td><?php echo e($hoso->namecitizen); ?></td>
        <td><?php echo e($hoso->file); ?></td>
        <td id="<?php echo e('trangthai'.$hoso->id_hoso); ?>"><?php echo e($hoso->status); ?></td>
        <td><?php echo e($hoso->name); ?></td>
        <td id="<?php echo e('thongbao'.$hoso->id_hoso); ?>">
          <?php if($hoso->note == null): ?>
            Không có thông báo gì
          <?php else: ?> 
            <?php echo e($hoso->note); ?>

          <?php endif; ?>
        </td>
        <td>
          <button class="btn btn-warning">
            <a href="<?php echo e(route('edit-file-hoso',$hoso->id_hoso)); ?>" style="color: white">
              Sửa File Hồ Sơ
            </a>
          </button>
        </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('citizen.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/citizen/tracuuhoso.blade.php ENDPATH**/ ?>