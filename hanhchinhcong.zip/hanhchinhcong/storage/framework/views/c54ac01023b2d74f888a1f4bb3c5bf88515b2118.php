<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('post-edit-file-hoso',$hoso->id)); ?>">
    <input type="file" value="<?php echo e($hoso->file); ?>" name="file">
    <button type="submit">OK</button>
    <?php echo e(csrf_field()); ?>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('citizen.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/citizen/editfilehoso.blade.php ENDPATH**/ ?>