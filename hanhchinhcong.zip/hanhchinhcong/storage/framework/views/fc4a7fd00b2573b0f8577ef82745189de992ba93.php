<?php $__env->startSection('content'); ?>
<div class="container">
<hr>





<div class="card bg-light">
<article class="card-body mx-auto" style="max-width: 400px;">
	<h4 class="card-title mt-3 text-center">Login</h4>
	
<form autocomplete="off" method="POST" action="<?php echo e(route('handle-dangnhap')); ?>">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label>Username</label>
      <input type="text" class="form-control" placeholder="Username" name="username">
    </div>
    <div class="form-group col-md-6">
      <label>Password</label>
      <input type="password" class="form-control" placeholder="Password" name="password">
    </div>
  </div>
  <?php if(isset($message)): ?>
    <div style="color: red"><?php echo e($message); ?></div>
  <?php endif; ?>
  <button type="submit" class="btn btn-danger">Đăng Nhập</button>
  <?php echo e(csrf_field()); ?>

</form>
</article>
</div> <!-- card.// -->

</div> 
<!--container end.//-->
<?php $__env->stopSection(); ?>
    






<?php echo $__env->make('citizen.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/citizen/dangnhap.blade.php ENDPATH**/ ?>