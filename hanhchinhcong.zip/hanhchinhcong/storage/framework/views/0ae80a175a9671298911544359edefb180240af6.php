<form role="form" action="<?php echo e(route('post-edit-nhanvien',$nhanvien->id)); ?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label class="sr-only" for="contact-name">Name</label>
        <input type="text" name="name" value="<?php echo e($nhanvien->name); ?>" class="form-control" id="inputEditName">
    </div>
    <div class="form-group">
        <label class="sr-only" for="contact-phone">Phone</label>
        <input type="text" name="phone" value="<?php echo e($nhanvien->phone); ?>" class="form-control" id="inputEditPhone">
    </div>
    <div class="form-group">
        <label class="sr-only" for="contact-email">Email</label>
        <input type="text" name="email" value="<?php echo e($nhanvien->email); ?>" class="form-control" id="inputEditEmail">
    </div>
    <div class="form-group">
        <label class="sr-only" for="contact-address">Address</label>
        <input type="text" name="address" value="<?php echo e($nhanvien->address); ?>" class="form-control" id="inputEditAddress">
    </div>
    <div class="form-group">
        <label class="sr-only" for="contact-message">Thủ tục quản lý</label>
        <input name="id_mathutuc" value="<?php echo e($nhanvien->id_mathutuc); ?>" class="contact-message form-control" id="inputEditIdMathutuc">
    </div>
    <button type="submit" class="btn btn-warning" id="buttonSaveEdit">Save</button>
    <?php echo e(csrf_field()); ?>

</form><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/admin/nhanvien/edit_nhanvien.blade.php ENDPATH**/ ?>