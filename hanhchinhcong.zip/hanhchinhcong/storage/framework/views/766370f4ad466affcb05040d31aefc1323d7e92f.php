<?php $__env->startSection('content'); ?>
<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">Tên Thủ Tục</th>
      <th scope="col"><?php echo e($thutuc[0]->namethutuc); ?></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Lĩnh Vực</th>
      <td><?php echo e($thutuc[0]->namelinhvuc); ?></td>
    </tr> 
    <tr>
      <th scope="row">Hướng dẫn nộp</th>
      <td>Ấn vào nút Nộp hồ sơ online</td>
    </tr> 
  </tbody>
  <tfoot>
      <tr>
          <th>
            <button class="btn btn-danger">
              <a href="<?php echo e(route('nop_ho_so',$thutuc[0]->id)); ?>" style="color:white">
              Nộp Hồ Sơ Online
              </a>
            </button>
          </th>
      </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('citizen.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/citizen/detailthutuc.blade.php ENDPATH**/ ?>