<?php $__env->startSection('content'); ?>
<div class="container">
<hr>





<div class="card bg-light">
<article class="card-body mx-auto" style="max-width: 400px;">
	<h4 class="card-title mt-3 text-center">Create Account</h4>
	
<form autocomplete="off" method="POST" action="<?php echo e(route('handle-dangky')); ?>">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label>Họ Và Tên</label>
      <input type="text" class="form-control" placeholder="Họ tên" name="name">
    </div>
    <div class="form-group col-md-6">
      <label>Số Điện Thoại</label>
      <input type="text" class="form-control" placeholder="Số điện thoại" name="phone">
    </div>
  </div>
  <div class="form-group">
    <label>Email</label>
    <input type="text" class="form-control" placeholder="Email" name="email">
  </div>
  <div class="form-group">
    <label>Địa Chỉ</label>
    <input type="text" class="form-control" placeholder="Địa chỉ" name="address">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label>Username</label>
      <input type="text" class="form-control" placeholder="Username" name="username">
    </div>
    
    <div class="form-group col-md-6">
      <label>Password</label>
      <input type="password" class="form-control" placeholder="Password" name="password">
    </div>
  </div>
  
  <button type="submit" class="btn btn-primary">Tạo Tài Khoản</button>
  <button class="btn btn-danger"><a href="<?php echo e(route('dangnhap')); ?>" style="color:white">Đăng Nhập</a></button>
  <?php echo e(csrf_field()); ?>

</form>
</article>
</div> <!-- card.// -->

</div> 
<!--container end.//-->
<?php $__env->stopSection(); ?>   






<?php echo $__env->make('citizen.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/citizen/dangky.blade.php ENDPATH**/ ?>