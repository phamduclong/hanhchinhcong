<?php $__env->startSection('content'); ?>
<h2 class="mt-4">Bộ Thủ Tục</h2>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">STT</th>
      <th scope="col">Tên Thủ Tục Hành Chính</th>
      <th scope="col">Mức Độ</th>
      <th scope="col">Lĩnh Vực</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $thutuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thutuc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($thutuc->id); ?></th>
      <td><a href=<?php echo e(route('detail_thutuc',$thutuc->id)); ?>><?php echo e($thutuc->namethutuc); ?></a></td>
      <td><?php echo e($thutuc->mucdo); ?></td>
      <td><?php echo e($thutuc->namelinhvuc); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('citizen.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/citizen/bothutuc.blade.php ENDPATH**/ ?>