<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Blank page
            <small>it all starts here</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('homeadmin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            
            <li class="active">
                <a href="<?php echo e(route('logout')); ?>">
                    Logout
                </a>
            </li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Danh sách thủ tục</h3>
                    </div>
                    <div class="box-body">
                        <!-- /.box-header -->
                        <div class="div">
                            <div class="row">
                                <div class="col-xs-4">
                                    <div class="form-group">
                                        <label>Tiêu đề</label>
                                        <input name="address" value="" class="form-control" placeholder="Nhập tiêu đề">
                                    </div>
                                </div>
                                
                                <div class="col-xs-2">
                                    <div class="form-group">
                                        <label>&nbsp;</label>
                                        <input class="form-control btn btn-primary" type="submit" value="Tìm kiếm">
                                    </div>
                                </div>
                                <?php if(Session::get('typeAdmin') == 'Admin'): ?>
                                <div class="col-xs-2">
                                    <div class="form-group">
                                        <label>&nbsp;</label>
                                        <a class="form-control btn btn-success" data-toggle="modal" href="<?php echo e(route('add-thutuc')); ?>">Thêm mới</a>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <table id="data_table" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th class="bg-primary">ID</th>
                                <th class="bg-primary" width="300px">Tên thủ tục</th>
                                <!--                                    <th class="bg-primary">Chức vụ</th>-->
                                <th class="bg-primary">Id Mã thủ tục</th>
                                <th class="bg-primary">Mức độ</th>
                                <th class="bg-primary">Id Mã lĩnh vực</th>
                                <?php if(Session::get('typeAdmin') == 'Admin'): ?>
                                <th class="bg-primary">Hành động</th>
                                <?php endif; ?>
                            </tr>
                            </thead>
                            <?php $__currentLoopData = $thutuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody id="show_data">
                                <tr>
                                    <td><?php echo e($tt->id); ?></td>
                                    <td><?php echo e($tt->namethutuc); ?></td>
                                    <td><?php echo e($tt->id_mathutuc); ?></td>
                                    <td><?php echo e($tt->mucdo); ?></td>
                                    <td><?php echo e($tt->id_malinhvuc); ?></td>
                                    <?php if(Session::get('typeAdmin') == 'Admin'): ?>
                                    <td>
                                        <button class="btn btn-action label label-danger" style="margin-right: 5px">
                                            <a href="<?php echo e(route('delete-thutuc',$tt->id)); ?>" style="color: white">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </button>
                                        <button class="btn btn-action label label-success">
                                            <a href="<?php echo e(route('edit-thutuc',$tt->id)); ?>" style="color: white">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                        </button>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer clearfix" id="paginate_div">
                        <ul class="pagination pull-right">
                            
                        </ul>
                    </div>
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_hanhchinh\hanhchinhcong\resources\views/admin/thutuc/list_thutuc.blade.php ENDPATH**/ ?>