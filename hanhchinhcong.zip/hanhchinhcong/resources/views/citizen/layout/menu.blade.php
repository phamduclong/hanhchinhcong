<div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Dịch Vụ Hành Chính </div>
      <div class="list-group list-group-flush">
        <a href="{{route('bothutuc')}}" class="list-group-item list-group-item-action bg-light">Bộ Thủ Tục</a>
        <a href="{{route('tracuuhoso')}}" class="list-group-item list-group-item-action bg-light">Tra Cứu Hồ Sơ Của Bạn</a>
        <a href="#" class="list-group-item list-group-item-action bg-light">Nộp Hồ Sơ Qua Mạng</a>
        <a href="#" class="list-group-item list-group-item-action bg-light">Thống Kê</a>
        <a href="#" class="list-group-item list-group-item-action bg-light">Hỏi Đáp - Kiến Nghị</a>
        <a href="#" class="list-group-item list-group-item-action bg-light">Dịch Vụ Khác</a>
      </div>
    </div>